document.addEventListener("DOMContentLoaded", function () {
    // Get references to the form and the section that will display the favorite list
    const faveFormEl = document.forms["fave_form"];
    const favSection = document.getElementById("fave-block");
    const favListContainer = document.getElementById("fave-list");
  
    // Build an array with the name and phone input pairs
    const friendFields = [
      { nameField: document.getElementById("name_1"), phoneField: document.getElementById("phone_1") },
      { nameField: document.getElementById("name_2"), phoneField: document.getElementById("phone_2") },
      { nameField: document.getElementById("name_3"), phoneField: document.getElementById("phone_3") }
    ];
  
    // Initially hide the favorite list section from both users and screen readers
    favSection.style.display = "none";
    favSection.setAttribute("aria-hidden", "true");
  
    // Define a class to create friend objects
    class Pal {
      constructor(fullName, contact) {
        this.fullName = fullName;
        this.contact = contact;
      }
    }
  
    // Function to check if all inputs are filled and return an array of Pal objects if valid
    function checkInputs() {
      let allValid = true;
      const pals = [];
  
      friendFields.forEach(({ nameField, phoneField }) => {
        const currentName = nameField.value.trim();
        const currentPhone = phoneField.value.trim();
  
        if (!currentName) {
          nameField.setAttribute("aria-invalid", "true");
          allValid = false;
        } else {
          nameField.removeAttribute("aria-invalid");
        }
  
        if (!currentPhone) {
          phoneField.setAttribute("aria-invalid", "true");
          allValid = false;
        } else {
          phoneField.removeAttribute("aria-invalid");
        }
  
        if (currentName && currentPhone) {
          pals.push(new Pal(currentName, currentPhone));
        }
      });
  
      return allValid ? pals : null;
    }
  
    // Function to render the list of friends in the designated container
    function renderFriends(pals) {
      // Clear any previous entries
      favListContainer.innerHTML = "";
      pals.forEach(pal => {
        const listItem = document.createElement("li");
        listItem.textContent = `Name: ${pal.fullName} Phone: ${pal.contact}`;
        favListContainer.appendChild(listItem);
      });
  
      // Hide the form from view
      faveFormEl.style.display = "none";
  
      // Make the favorite section visible for both visual users and assistive technologies
      favSection.style.display = "block";
      favSection.removeAttribute("aria-hidden");
    }
  
    // Listen for the form submission event
    faveFormEl.addEventListener("submit", function (evt) {
      evt.preventDefault();
      const pals = checkInputs();
  
      if (pals) {
        renderFriends(pals);
      } else {
        // If validation fails, keep the favorites section hidden
        favSection.style.display = "none";
        favSection.setAttribute("aria-hidden", "true");
      }
    });
  
    // Reset validation state when users start typing in the inputs
    friendFields.forEach(({ nameField, phoneField }) => {
      nameField.addEventListener("input", function () {
        if (nameField.value.trim()) {
          nameField.removeAttribute("aria-invalid");
        }
      });
  
      phoneField.addEventListener("input", function () {
        if (phoneField.value.trim()) {
          phoneField.removeAttribute("aria-invalid");
        }
      });
    });
  });
  